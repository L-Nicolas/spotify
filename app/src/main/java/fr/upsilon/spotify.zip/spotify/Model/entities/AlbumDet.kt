package com.esgi.yfitops.models.entities

class AlbumDet(id: Int, title: String, dateY: String) {
    var id: Int = 0
    var title: String = ""
    var dateY: String = ""

    init {
        this.id = id
        this.title = title
        this.dateY = dateY
    }

}